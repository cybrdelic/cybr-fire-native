# Storage, ownership, and bounded capture

## Numerical pipeline

Scene descriptions are immutable configuration. A `Simulation` owns its fixed
master clock, persistent fields, source descriptors, geometry, pressure backend,
and optional one-way particle system. Operators do not branch on scene names.

The existing stage order is retained: reservoir exchange, solid enforcement,
forces, velocity transport, projection, scalar transport, solid enforcement,
reaction, particles. The renderer consumes fields without evolving the clock.
The native backend does not substitute a finer optical noise field for coarse
fluid dynamics: the primary gas and velocity arrays themselves are larger.

`Domain.native_fields` selects two concrete storage implementations. The legacy
path retains SSBOs and sampled transport caches for verification. The new path
uses `ImageField`, an authoritative RGBA32F image with explicit read/write,
slab readback, binding, and release. Shared shader accessor functions dispatch at
compile time to image or buffer access. Both paths execute the same numerical
operators. Native transport samples its authoritative images directly instead
of copying every field to a second texture.

The earlier vec4-per-cell path encountered a measured 128 MiB maximum single
SSBO block. 8,388,608 RGBA32F values reach that byte limit. A 224 × 392 × 224
scalar image is 314,703,872 bytes; the new tests deliberately access indices on
both sides of the old limit, and the capture evolves the complete larger image.
This is still dense storage. The software domain limit is 32 million cells,
subject to adapter capabilities and actual memory availability; it is not an
unlimited-grid claim.

## Scratch lifetime contract

There are three scalar images and three staggered-velocity images. Published
`q` and `vel` references never alias one another or scratch. After a transport
stage, source/output handles swap; the prediction handle does not.

Vorticity and the reaction ledger reuse scalar prediction storage at different
stages. Assembled forces reuse velocity prediction storage before velocity
advection overwrites it. No operator assumes these scratch values remain valid
outside its documented stage. The chemistry ledger is the current reaction
stage's diagnostic, not a persistent global conservation ledger. Pressure uses
separate scalar storage. Tests compare both authoritative state and the last
reaction ledger with the unaliased legacy implementation.

## Rendering above a single output-buffer limit

`render_hdr(region=...)` distinguishes the full camera raster from the bounded
output window. Projection, random seeds, sample positions, and particle tile
coordinates use the full raster's global pixel coordinates. Only output
addressing uses the local band. `render_tiled_rgb` walks row bands, invokes the
same volume integrator, tone maps those directly computed HDR samples, and
assembles the output image without resampling.

Tests compare whole-frame and multiple band heights bit for bit on a frozen
state, including a subregion at a nonzero horizontal/vertical offset. Camera
ray metrics are summed over bands. Bloom is explicitly rejected in this RGB
band path because a convolution local to each band would create seams. The
published captures use no bloom; a proper overlapping/global bloom pass is
not silently claimed.

Optical emission/extinction remains full-grid FP32. Angular incident light is
an approximate coarser cache, as in the existing renderer. The geometric
camera resolution is not the lighting-cache resolution. This release does not
claim converged multiple scattering or experimentally measured soot optics.

Particle tiles retain demand-sized allocation. Equal-depth events are now
sorted by particle identifier in addition to depth, rather than by unstable
atomic insertion order. This repairs the crowded-event reproducibility
regression without dropping, brightening, or relocating particles.

## Checkpoints and resource pressure

Native diagnostics read small z slabs and accumulate global measures in
float64. Streamed checkpoint writes emit standard NPY members within an atomic
ZIP/NPZ file, avoiding another pair of entire CPU state arrays. Read/load remains
transactionally validated and requires additional transient host memory; it
occurs before allocating the renderer in the capture runner. This release does
not claim a constant-memory general loader or constant-memory `snapshot()`.

Large captures write lossless PNG frame masters before encoding. The solver and
renderer close before FFmpeg starts, so codec lookahead does not compete with
large simulation fields. Interrupted encoding can be retried from those frames.
The initial development path that exceeded memory during whole-field diagnostics
is retained in the development evidence; it is not relabeled a successful run.

The normal completed-capture indicator is `capture.json`, emitted only after
all frames/stills, final checkpoint, and encoder have completed. Progress files
and temporary MP4 filenames are never release evidence by themselves.
