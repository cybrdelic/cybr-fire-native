# Verification boundaries

The inherited numerical/runtime suite is rerun, not merely copied. Additional
native-field tests compare buffer and image executions, transport modes,
particles, optics, ownership, and checkpoint behavior. They also allocate a
real field beyond the previously limiting byte range. Streaming tests compare
slabs, whole-array diagnostics, exact camera crops/bands, checkpoint contents,
restart continuation, and invalid-input rejection.

Parity on the tested inputs establishes implementation agreement; it does not
prove either discretization is a physically correct combustion model. Finer
cells and a smaller master tick are not substitutes for a grid-convergence
experiment. The high-resolution capture has separate sampled field diagnostics
and final-state checks, not an invented long-duration stability certificate.

The media validator reads actual MP4 dimensions, rate, and decoded frame count;
fully decodes the video; verifies every lossless master frame; compares their
pixel/file hashes with the capture records; and checks the actual NPZ/NPY array
headers. It verifies native camera ray count rather than inferring resolution
from a requested filename. Separate stills are checked independently. Display
thumbnails and optional 1:1 crops are distinguished from newly rendered stills.

The video is 24 fps playback of 120 Hz physical ticks, giving 5× slow motion.
No additional frames are inserted to achieve that playback. The provided
metadata separates physical duration, presentation duration, simulation cost,
lighting cost, primary rendering/readback, stills, and encoding.

All measurements come from the named local adapter. It is Mesa software
OpenGL, not a measured RTX or other hardware GPU. No whole-engine speedup,
real-time throughput, EmberGen comparison, experimental flame calibration,
chemistry validation, or production-readiness certification is claimed.

The exact source files and their hashes are part of the delivery. The source
ZIP is extracted independently and its numerical checks are rerun before
packaging validation is marked successful. Test names inherited from earlier
versions identify their test family, not a claim that the old program executed
in place of V7.
