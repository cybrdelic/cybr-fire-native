#!/usr/bin/env python3
"""Explicit, bounded-working-set initialization of a V7 native-grid checkpoint.

This is an initial-condition transfer, not a bitwise equivalent restart. Sources
and physical parameters are taken from --scene; the input contributes cell
averages, MAC velocities, and time. Particles are deliberately initialized empty.
Reproduction of the published clip uses its supplied V7 starting checkpoint
instead of rerunning this transfer from an arbitrary earlier state.
"""
from pathlib import Path
from dataclasses import replace
import argparse, ctypes, gc, hashlib, json, sys, tempfile, time
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from cybrfire.config import scene_from_dict
from cybrfire.gpu import ComputeContext
from cybrfire.solver import Simulation
from cybrfire.remesh import conservative_scalars, staggered_velocity
from cybrfire.__main__ import code_digest


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def trim():
    gc.collect()
    try:
        ctypes.CDLL('libc.so.6').malloc_trim(0)
    except (AttributeError, OSError):
        pass


def main():
    p = argparse.ArgumentParser(description=__doc__)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--input', type=Path)
    g.add_argument('--cold-start', action='store_true')
    p.add_argument('--scene', type=Path, default=Path('examples/19-million-4k.json'))
    p.add_argument('--output', type=Path, default=Path('cache/v7-capture-start.npz'))
    p.add_argument('--warmup-ticks', type=int, default=24)
    a = p.parse_args()
    if a.warmup_ticks < 0:
        raise ValueError('Warmup ticks must be nonnegative')
    if a.input and a.input.resolve() == a.output.resolve():
        raise ValueError('Initialization must not overwrite the source checkpoint')
    if a.output.exists():
        raise FileExistsError('Choose a new output path; initialization never replaces an existing checkpoint')
    scene = scene_from_dict(json.loads(a.scene.read_text()))
    scene.validate()
    if not scene.domain.native_fields:
        raise ValueError('This initializer requires the native image-field backend')
    start = time.perf_counter()
    report = {'operation': 'explicit_initial_condition_transfer' if a.input else 'cold_start',
              'source_file_sha256': sha256(a.input) if a.input else None,
              'source_core_sha256': code_digest(), 'new_grid': list(scene.domain.shape),
              'new_spacing_m': scene.domain.spacing, 'tick_s': scene.domain.tick,
              'warmup_ticks': a.warmup_ticks, 'not_an_equivalent_restart': True,
              'particles_initialized_empty': True}
    a.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='cybr-v7-transfer-', dir=a.output.parent) as temporary:
        folder = Path(temporary)
        target_tick = 0
        if a.input:
            with np.load(a.input, allow_pickle=False) as z:
                version = int(z['version'])
                if version not in (5, 6, 7):
                    raise ValueError('Supported explicit import versions are 5, 6 and 7')
                old = scene_from_dict(json.loads(str(z['config'])))
                old_shape = tuple(old.domain.shape)
                old_time = int(z['tick']) * old.domain.tick
                if int(z['tick']) < 0:
                    raise ValueError('Invalid source time')
                target_tick = round(old_time / scene.domain.tick)
                if abs(target_tick * scene.domain.tick - old_time) > 1e-8:
                    raise ValueError('The target clock cannot represent the source time exactly')
                if not np.allclose(np.array(old_shape) * old.domain.spacing,
                                   np.array(scene.domain.shape) * scene.domain.spacing,
                                   rtol=1e-8, atol=1e-8):
                    raise ValueError('Source and target physical domains differ')
                q = z['q']
                if q.shape != (int(np.prod(old_shape)), 4) or not np.isfinite(q).all() or q.min() < -1e-4:
                    raise ValueError('Invalid source scalar field')
                before = q.sum(axis=0, dtype=np.float64) * old.domain.spacing**3
                mapped = conservative_scalars(q.reshape(*old_shape[::-1], 4), scene.domain.shape)
                after = mapped.sum(axis=(0, 1, 2), dtype=np.float64) * scene.domain.spacing**3
                np.save(folder / 'q.npy', mapped.reshape(-1, 4))
                del q, mapped
                trim()
                v = z['velocity']
                if v.shape != (int(np.prod(np.array(old_shape) + 1)), 4) or not np.isfinite(v).all():
                    raise ValueError('Invalid source MAC velocity')
                mapped = staggered_velocity(v.reshape(*(np.array(old_shape[::-1]) + 1), 4),
                                             old_shape, scene.domain.shape)
                np.save(folder / 'v.npy', mapped.reshape(-1, 4))
                del v, mapped
                trim()
            report.update(source_version=version, old_grid=list(old_shape), initial_time_s=old_time,
                          scalar_integrals_before=before.tolist(), scalar_integrals_after=after.tolist(),
                          relative_integral_errors=(abs(after-before)/np.maximum(abs(before), 1e-12)).tolist())
        ctx = ComputeContext()
        try:
            sim = Simulation(ctx, scene)
            if a.input:
                for name, field in [('q', sim.q), ('v', sim.vel)]:
                    mapped = np.load(folder / (name+'.npy'), mmap_mode='r', allow_pickle=False)
                    field.write(mapped)
                    del mapped
                sim.tick = target_tick
                trim()
                sim.project_velocity(reset=True)
                ctx.finish()
            for i in range(a.warmup_ticks):
                sim.step()
                ctx.finish()
                print(f'Warmup {i+1}/{a.warmup_ticks}: physical time {sim.time:.8f}', flush=True)
            report['state'] = sim.diagnostics()
            sim.save(a.output)
            report['adapter'] = ctx.info
        finally:
            ctx.close()
    report['checkpoint_sha256'] = sha256(a.output)
    report['wall_seconds'] = time.perf_counter()-start
    a.output.with_suffix('.initialization.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
