#!/usr/bin/env python3
"""Verify completed native capture bytes, not just requested settings."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, subprocess, sys, zipfile
import numpy as np
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from cybrfire.__main__ import code_digest


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return h.hexdigest()


def array_header(archive, member):
    with archive.open(member) as f:
        version = np.lib.format.read_magic(f)
        if version == (1, 0):
            shape, order, dtype = np.lib.format.read_array_header_1_0(f)
        elif version == (2, 0):
            shape, order, dtype = np.lib.format.read_array_header_2_0(f)
        else:
            raise ValueError(f'Unsupported NPY header {version}')
        payload_offset = f.tell()
    return {'shape': list(shape), 'dtype': dtype.str, 'fortran_order': bool(order),
            'payload_offset': payload_offset, 'member_bytes': archive.getinfo(member).file_size}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--capture', type=Path, required=True)
    p.add_argument('--checkpoint', type=Path, required=True)
    a = p.parse_args()
    root = Path(__file__).resolve().parents[1]
    report = json.loads((a.capture/'capture.json').read_text())
    checks = []
    def check(name, success, **details):
        checks.append({'name': name, 'passed': bool(success), **details})
        print(('PASS ' if success else 'FAIL ') + name + ' ' + json.dumps(details), flush=True)
        if not success:
            raise AssertionError(name)
    check('capture_complete', report['status'] == 'completed_capture')
    check('current_core_fingerprint', code_digest() == report['core_sha256'])
    check('runner_fingerprint', sha256(root/'tools/replay_v7.py') == report['capture_runner_sha256'])
    dims = tuple(report['video_dimensions'])
    frames = report['frames']
    grid = tuple(report['grid'])
    check('full_native_grid', grid == (224, 392, 224) and report['simulated_cells'] == 19_668_992)
    check('native_4K_dimensions', dims == (2160, 3840))
    check('declared_FP32_storage', report['storage_backend'] == 'native_images')
    for name, file, expected in [('start', a.checkpoint, report['checkpoint_source_sha256']),
                                 ('final', a.capture/'final-state.npz', report['checkpoint_final_sha256'])]:
        check(name+'_checkpoint_hash', sha256(file) == expected)
        with zipfile.ZipFile(file) as z:
            check(name+'_checkpoint_crc', z.testzip() is None)
            headers = {k: array_header(z, k+'.npy') for k in ['q', 'velocity', 'pressure']}
            expected_shapes = {'q': [int(np.prod(grid)), 4],
                               'velocity': [int(np.prod(np.asarray(grid)+1)), 4],
                               'pressure': [int(np.prod(grid))]}
            for k, shape in expected_shapes.items():
                h = headers[k]
                check(name+'_actual_'+k+'_array', h['shape'] == shape and np.dtype(h['dtype']) == np.dtype('float32')
                      and h['member_bytes'] == h['payload_offset'] + int(np.prod(shape))*4,
                      header=h)
        with np.load(file, allow_pickle=False) as z:
            check(name+'_version', int(z['version']) == 7)
            config = json.loads(str(z['config']))
            check(name+'_configured_grid', tuple(config['domain']['shape']) == grid
                  and bool(config['domain']['native_fields']))
    video = a.capture/report['video_file']
    check('video_hash', sha256(video) == report['video_sha256'])
    probe = json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0',
        '-show_entries','stream=codec_name,width,height,r_frame_rate,avg_frame_rate,nb_read_frames,duration,pix_fmt',
        '-of','json',str(video)], text=True))['streams'][0]
    check('decoded_dimensions', (probe['width'],probe['height']) == dims, actual=probe)
    check('decoded_frame_count', int(probe['nb_read_frames']) == frames)
    check('decoded_frame_rate', probe['r_frame_rate'] == f"{report['playback_fps']}/1")
    check('decoded_duration', abs(float(probe['duration']) - report['playback_duration_s']) < 1e-5)
    subprocess.run(['ffmpeg','-v','error','-xerror','-threads','2','-i',str(video),'-f','null','-'],check=True)
    check('entire_video_decodes', True)
    # This diagnostic downsample is not used in the delivered video or stills.
    raw = subprocess.check_output(['ffmpeg','-v','error','-threads','2','-i',str(video),
        '-vf','scale=90:160','-pix_fmt','rgb24','-f','rawvideo','-'])
    check('diagnostic_decode_count', len(raw) == frames*90*160*3)
    decoded = np.frombuffer(raw,np.uint8).reshape(frames,160,90,3)
    distinct = len({hashlib.sha256(f.tobytes()).hexdigest() for f in decoded})
    adjacent = np.abs(np.diff(decoded.astype(np.float32),axis=0)).mean(axis=(1,2,3))
    check('distinct_decoded_frames', distinct == frames, unique=distinct,
          mean_adjacent_difference_8bit=float(adjacent.mean()), minimum_adjacent_difference_8bit=float(adjacent.min()))
    masters = sorted((a.capture/'frames').glob('*.png'))
    check('lossless_master_count', len(masters) == frames)
    for i, (path, measured) in enumerate(zip(masters, report['measurements'])):
        check(f'master_{i:03d}_file_hash', sha256(path) == measured['png_sha256'])
        with Image.open(path) as image:
            check(f'master_{i:03d}_native_pixels', image.size == dims and image.mode == 'RGB'
                  and hashlib.sha256(image.tobytes()).hexdigest() == measured['rgb_sha256'])
        check(f'master_{i:03d}_ray_count', measured['camera_rays'] == dims[0]*dims[1]*report['samples_per_pixel'])
    ticks = np.array([m['simulation_tick'] for m in report['measurements']], dtype=np.int64)
    physical = np.array([m['physical_time_s'] for m in report['measurements']])
    check('consecutive_physical_ticks', np.all(np.diff(ticks) == report['ticks_per_frame']))
    check('physical_time_matches_tick', np.allclose(physical, ticks*report['physical_tick_s'],rtol=0,atol=1e-12))
    check('explicit_slow_motion', abs(report['slow_motion_factor'] - 5.0) < 1e-12)
    for i, still in enumerate(report['stills']):
        path = a.capture/still['file']
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            check(f'independent_still_{i+1}', image.size == (3240,5760) and still['independently_rendered']
                  and still['samples_per_pixel'] == 2 and sha256(path) == still['sha256'], dimensions=list(image.size))
    check('two_independent_stills', len(report['stills']) == 2)
    for m in report['measurements']:
        if 'diagnostics' in m:
            d = m['diagnostics']
            check(f"field_snapshot_{m['frame']:03d}_admissible", d['finite'] and min(d['min_species']) >= -1e-4
                  and d['max_species'][1] <= .27001 and d['floor_normal_max'] == 0.)
    check('final_field_finite', report['final_state']['finite'])
    families = ['tests','extended-tests','runtime-tests','v5-tests','v6-tests',
                'particle-allocation-tests','native-field-tests','streaming-tests']
    tests = {}
    for family in families:
        path = root/'evidence'/(family+'.json')
        r = json.loads(path.read_text())
        check('regressions_'+family, r['failed'] == 0)
        tests[family] = {'passed':r['passed'], 'failed':r['failed'], 'sha256':sha256(path)}
    for name in ['legacy-regressions','native-field-tests','streaming-tests']:
        check(name+'_actual_process_success', (root/'evidence'/(name+'.exit')).read_text().strip() == '0')
    native = json.loads((root/'evidence/native-field-tests.json').read_text())
    scene = json.loads((a.capture/'scene.json').read_text())
    nominal_budget = scene['domain']['trace_courant']*scene['domain']['max_trace_steps']
    sampled_courant = max([m['diagnostics']['cfl_component'] for m in report['measurements'] if 'diagnostics' in m]
                         + [report['final_state']['cfl_component']])
    accuracy = {'maximum_sampled_face_component_courant': sampled_courant,
                'nominal_local_trace_budget': nominal_budget,
                'exceeds_nominal_budget': sampled_courant > nominal_budget,
                'qualification': 'Domain-wide face-component diagnostic, not a measured characteristic error. Boundedness and finer cells do not establish time/grid convergence.'}
    result = {'release':'CYBR FIRE V7 / native 4K', 'status':'verified_completed_capture',
              'verified_utc':datetime.now(timezone.utc).isoformat(), 'passed':len(checks),'failed':0,
              'accuracy_diagnostic':accuracy,'native_dimensions':list(dims),'simulated_grid':list(grid),'actual_cells':report['simulated_cells'],
              'physical_spacing_m':report['cell_spacing_m'],'slow_motion_factor':report['slow_motion_factor'],
              'video':{'file':video.name,'bytes':video.stat().st_size,'sha256':sha256(video),'probe':probe,
                       'full_decode':True,'unique_frames':distinct},
              'independent_stills':report['stills'],'tests':tests,
              'numerical_runtime_checks':sum(r['passed'] for r in tests.values()),
              'core_sha256':report['core_sha256'],'capture_runner_sha256':report['capture_runner_sha256'],
              'adapter':report['adapter'],'checks':checks,
              'no_upscaling':True,'no_interpolated_frames':True,'no_image_generation':True,
              'limitations':{'experimental_physical_validation':False,'grid_convergence_study':False,
                             'hardware_GPU_benchmark':False,'EmberGen_comparison':False,
                             'all_native_from_zero_history':False,'one_way_particles':True,
                             'transport_exactly_conservative':False},
              'previous_capture_comparison':{'old_grid':[160,280,160], 'old_cells':7168000,
                  'old_video_dimensions':[720,960],'cell_count_ratio':report['simulated_cells']/7168000,
                  'linear_grid_ratio':224/160,'video_pixel_ratio':dims[0]*dims[1]/(720*960),
                  'matched_physical_trajectory_or_camera':False}}
    (a.capture/'validation.json').write_text(json.dumps(result,indent=2))
    print(f"VERIFIED: {len(checks)} media/release checks; {result['numerical_runtime_checks']} numerical/runtime checks", flush=True)

if __name__ == '__main__':
    main()
