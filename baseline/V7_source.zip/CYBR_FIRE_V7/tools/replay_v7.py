#!/usr/bin/env python3
"""Native-resolution frame sequence and offline encoding from a V7 checkpoint.

The solver and renderer finish before the encoder starts. This keeps codec
lookahead memory out of the simulation's working set, preserves lossless frame
masters, and allows encoding to be retried without repeating fluid simulation.
"""
from pathlib import Path
from dataclasses import replace
import argparse,sys,time,json,hashlib,subprocess,ctypes,gc,os,shutil
import numpy as np
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cybrfire.config import scene_from_dict
from cybrfire.gpu import ComputeContext
from cybrfire.solver import Simulation
from cybrfire.render import VolumeRenderer
from cybrfire.__main__ import code_digest

def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def trim():
 gc.collect()
 try:ctypes.CDLL('libc.so.6').malloc_trim(0)
 except Exception:pass

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--out',type=Path,default=Path('captures/v7-4k'))
 p.add_argument('--frames',type=int,default=48);p.add_argument('--fps',type=int,default=24);p.add_argument('--ticks-per-frame',type=int,default=1)
 p.add_argument('--width',type=int,default=2160);p.add_argument('--height',type=int,default=3840);p.add_argument('--samples',type=int,default=1)
 p.add_argument('--still-width',type=int,default=3240);p.add_argument('--still-height',type=int,default=5760);p.add_argument('--still-samples',type=int,default=2)
 p.add_argument('--band-height',type=int,default=128);p.add_argument('--crf',type=int,default=14)
 a=p.parse_args()
 if a.frames<2 or a.frames>24000 or min(a.width,a.height)<64 or a.width%2 or a.height%2 or not 1<=a.fps<=120 or not 1<=a.ticks_per_frame<=120 or not 0<=a.crf<=51:raise ValueError('Invalid capture parameters')
 start=time.perf_counter()
 def log(m):print(f'{time.perf_counter()-start:.2f}s {m}',flush=True)
 a.out.mkdir(parents=True,exist_ok=True);masters=a.out/'frames';masters.mkdir(exist_ok=True)
 with np.load(a.checkpoint,allow_pickle=False) as z:
  if int(z['version'])!=7:raise ValueError('Expected a V7 checkpoint')
  scene=scene_from_dict(json.loads(str(z['config'])))
 scene=replace(scene,render=replace(scene.render,width=a.width,height=a.height,samples=a.samples,bloom=0.))
 scene.validate();(a.out/'scene.json').write_text(json.dumps(scene.to_dict(),indent=2))
 core=code_digest();runner=digest(__file__)
 ctx=ComputeContext();log('Allocating native simulation fields')
 sim=Simulation(ctx,scene);sim.load(a.checkpoint);trim();log('Checkpoint loaded and validated')
 renderer=VolumeRenderer(ctx,sim);initial=sim.diagnostics();capture_start=sim.time
 stats=[];stills=[]
 for f in range(a.frames):
  t=time.perf_counter()
  if f:sim.step(a.ticks_per_frame)
  ctx.finish();sm=(time.perf_counter()-t)*1000
  t=time.perf_counter();renderer.prepare();ctx.finish();lm=(time.perf_counter()-t)*1000
  t=time.perf_counter();rgb=renderer.render_tiled_rgb(width=a.width,height=a.height,samples=a.samples,seed=f,prepare=False,band_height=a.band_height);ctx.finish();rm=(time.perf_counter()-t)*1000
  dest=masters/f'{f:06d}.png';tmp=dest.with_suffix('.tmp')
  Image.fromarray(rgb).save(tmp,format='PNG',compress_level=3);tmp.replace(dest)
  row={'frame':f,'physical_time_s':sim.time,'simulation_tick':sim.tick,'presentation_time_s':f/a.fps,
       'simulation_ms':sm,'lighting_preparation_ms':lm,'native_primary_readback_tonemap_ms':rm,
       'rgb_sha256':hashlib.sha256(rgb.tobytes()).hexdigest(),'png_sha256':digest(dest),
       'camera_rays':renderer.statistics()['camera_rays']}
  if f%12==0 or f==a.frames-1:row['diagnostics']=sim.diagnostics()
  stats.append(row)
  (a.out/'progress.json').write_text(json.dumps(dict(stage='native_frames',completed=f+1,total=a.frames,last_frame=row,wall_s=time.perf_counter()-start),indent=2))
  if f==0:
   shutil.copyfile(dest,a.out/'V7_first_frame_2160x3840.png')
   thumb=Image.fromarray(rgb);thumb.thumbnail((900,1600));thumb.save(a.out/'preview.jpg',quality=95,subsampling=0)
  log(f'Frame {f+1}/{a.frames} physical={sim.time:.6f} sim={sm/1000:.3f}s lighting={lm/1000:.3f}s native rays={rm/1000:.3f}s')
  if f in (a.frames//3,2*a.frames//3):
   t=time.perf_counter();name=f'V7_detail_{len(stills)+1:02d}_{a.still_width}x{a.still_height}.png'
   still=renderer.render_tiled_rgb(width=a.still_width,height=a.still_height,samples=a.still_samples,seed=f,prepare=False,band_height=min(a.band_height,96))
   Image.fromarray(still).save(a.out/name,compress_level=4)
   stills.append({'file':name,'dimensions':[a.still_width,a.still_height],'samples_per_pixel':a.still_samples,
       'physical_time_s':sim.time,'frame':f,'independently_rendered':True,'sha256':digest(a.out/name),'render_and_png_seconds':time.perf_counter()-t})
   del still;trim();log(f'Completed native still {name}')
  (a.out/'measurements.partial.json').write_text(json.dumps({'frames':stats,'stills':stills},indent=2))
 final=sim.diagnostics();renderer.close();trim()
 log('Saving final state with bounded-memory checkpoint writer')
 checkpoint_out=a.out/'final-state.npz';sim.save(checkpoint_out);ctx.close();trim()
 if code_digest()!=core:raise RuntimeError('Core changed during capture; release blocked')
 render_wall=time.perf_counter()-start
 log('Numerical capture complete. Encoding lossless PNG masters to MP4.')
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate',str(a.fps),'-i',str(masters/'%06d.png'),'-frames:v',str(a.frames),
      '-an','-c:v','libx264','-threads','2','-preset','medium','-crf',str(a.crf),'-pix_fmt','yuv420p',
      '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-movflags','+faststart',str(a.out/'V7_19-million_4K.partial.mp4')]
 with (a.out/'ffmpeg.log').open('wb') as log_file:subprocess.run(cmd,stderr=log_file,check=True)
 video=a.out/'V7_19-million_4K.mp4';(a.out/'V7_19-million_4K.partial.mp4').replace(video)
 result={'release':'CYBR FIRE V7 / native 4K detail study','status':'completed_capture','core_sha256':core,'capture_runner_sha256':runner,
   'checkpoint_source_sha256':digest(a.checkpoint),'checkpoint_final_sha256':digest(checkpoint_out),'adapter':ctx.info,
   'grid':list(sim.shape),'simulated_cells':sim.n,'cell_spacing_m':sim.h,'physical_domain_m':(np.asarray(sim.shape)*sim.h).tolist(),
   'field_format':'Authoritative RGBA32F image fields; FP32 gas and staggered velocity','storage_backend':'native_images',
   'video_file':video.name,'video_sha256':digest(video),'video_dimensions':[a.width,a.height],'native_rays_per_frame':a.width*a.height*a.samples,
   'samples_per_pixel':a.samples,'playback_fps':a.fps,'frames':a.frames,'playback_duration_s':a.frames/a.fps,
   'physical_tick_s':scene.domain.tick,'ticks_per_frame':a.ticks_per_frame,'slow_motion_factor':1/(scene.domain.tick*a.ticks_per_frame*a.fps),
   'physical_sample_time_s':[capture_start,final['time']],'physical_span_s':final['time']-capture_start,
   'no_upscaling':True,'no_frame_interpolation':True,'no_image_generation':True,'no_render_density_warp':True,'no_post_sharpening':True,
   'bloom':False,'key_light_intensity':scene.render.key_intensity,'floor_visible':scene.render.floor,
   'stills':stills,'measurements':stats,'initial_state':initial,'final_state':final,
   'capture_wall_s':render_wall,'total_wall_s':time.perf_counter()-start,
   'simulation_median_ms':float(np.median([r['simulation_ms'] for r in stats[1:]])),
   'lighting_median_ms':float(np.median([r['lighting_preparation_ms'] for r in stats])),
   'native_render_median_ms':float(np.median([r['native_primary_readback_tonemap_ms'] for r in stats])),
   'timing_scope':'Software OpenGL synchronized wall time, not hardware GPU or real-time performance. Encoding and separate stills excluded from per-frame medians.',
   'hardware_GPU_benchmark':False,'EmberGen_comparison':False,'experimental_calibration':False,
   'initialization':'Restored validated V7 checkpoint, itself conservatively transferred from the supplied V5 state and evolved for 24 native-grid 120 Hz ticks before this capture.',
   'encoder_command':cmd,'lossless_frame_masters_retained':True}
 (a.out/'capture.json').write_text(json.dumps(result,indent=2));log('COMPLETE')
if __name__=='__main__':main()
