#!/usr/bin/env python3
"""Package only a fully decoded, verified native-resolution capture."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, html, json, os, shutil, subprocess, sys, zipfile
from PIL import Image


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()


def checked_archive(path, entries):
    temp=path.with_suffix('.partial.zip')
    with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for file, arc in entries:
            # Already compressed inputs are stored without another compression pass.
            mode=zipfile.ZIP_STORED if file.suffix.lower() in {'.mp4','.png','.jpg','.npz'} else zipfile.ZIP_DEFLATED
            z.write(file,arc,compress_type=mode)
    with zipfile.ZipFile(temp) as z:
        bad=z.testzip()
        if bad:raise RuntimeError(f'Archive CRC failure: {bad}')
        count=len(z.infolist())
    temp.replace(path)
    return {'file':path.name,'bytes':path.stat().st_size,'sha256':digest(path),'members':count,'zip_crc_check':'passed'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--destination',type=Path,default=Path('/mnt/data'))
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    a.destination.mkdir(parents=True,exist_ok=True)
    env={**os.environ,'LP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'4'}
    with (root/'evidence/media-validation.log').open('wb') as log:
        subprocess.run([sys.executable,str(root/'tools/validate_capture.py'),'--capture',str(a.capture),'--checkpoint',str(a.checkpoint)],
                       env=env,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=root)
    data=json.loads((a.capture/'capture.json').read_text());valid=json.loads((a.capture/'validation.json').read_text())
    # Query the actual adapter caps used by this implementation; no GPU marketing assumptions.
    import ctypes as C
    sys.path.insert(0,str(root))
    from cybrfire.gpu import ComputeContext
    device=ComputeContext()
    try:
        caps={}
        for name,enum in [('GL_MAX_SHADER_STORAGE_BLOCK_SIZE',0x90DE),('GL_MAX_3D_TEXTURE_SIZE',0x8073),('GL_MAX_IMAGE_UNITS',0x8F38)]:
            value=C.c_int();device.glGetIntegerv(enum,C.byref(value));caps[name]=value.value
        device.check()
        caps['adapter']=device.info
    finally:device.close()
    (root/'evidence/device-limits.json').write_text(json.dumps(caps,indent=2))
    if valid['status']!='verified_completed_capture' or valid['failed']:raise RuntimeError('Capture is not verified')
    # A thumbnail is explicitly not one of the separately rendered large stills.
    first_still=a.capture/data['stills'][0]['file']
    with Image.open(first_still) as image:
        thumb=image.copy();thumb.thumbnail((900,1600));thumb.save(a.capture/'preview.jpg',quality=95,subsampling=0)
        # Exact 1:1 pixels from the native still. No resizing or sharpening.
        x0=(image.width-1440)//2;y0=int(image.height*.40)
        crop_box=(x0,y0,x0+1440,y0+1440)
        image.crop(crop_box).save(a.capture/'V7_native_pixel_crop.png',compress_level=4)
    crop={'file':'V7_native_pixel_crop.png','source':first_still.name,'box':list(crop_box),
          'operation':'lossless 1:1 crop, no resampling','sha256':digest(a.capture/'V7_native_pixel_crop.png')}
    (a.capture/'derived-media.json').write_text(json.dumps({'pixel_crop':crop,'preview':{'operation':'downsampled navigation thumbnail','not_a_native_resolution_still':True}},indent=2))
    stats=f"{data['simulated_cells']:,} cells · {data['video_dimensions'][0]} × {data['video_dimensions'][1]} · 5× slow motion"
    still_cards=''.join(f'<a class="still" href="{html.escape(s["file"])}"><img loading="lazy" src="{html.escape(s["file"])}" alt="Independent native-resolution fire still"><span>Open {s["dimensions"][0]} × {s["dimensions"][1]} original</span></a>' for s in data['stills'])
    gallery=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CYBR FIRE V7 — native 4K</title>
<style>body{{margin:0;background:#0c1119;color:#e7edf6;font:16px/1.6 system-ui,sans-serif}}main{{max-width:1100px;margin:40px auto;padding:0 22px}}h1{{font-size:clamp(32px,6vw,64px);line-height:1.05;letter-spacing:-.04em;margin:0 0 14px}}.eyebrow{{letter-spacing:.15em;font-size:12px;color:#a9bacb}}a{{color:#bfd5ed}}video{{display:block;width:min(100%,680px);max-height:90vh;margin:32px auto;background:#080c12}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px}}.still{{border:1px solid #253246;text-decoration:none;background:#121b28}}.still img{{width:100%;display:block}}.still span{{display:block;padding:16px}}.note{{max-width:800px;color:#b4c0cf}}footer{{border-top:1px solid #253246;margin-top:40px;padding-top:22px}}</style>
<main><p class="eyebrow">NUMERICAL VOLUME CAPTURE / V7</p><h1>Fire at native 4K.</h1><p>{stats}</p>
<p class="note">Every frame is integrated from a 224 × 392 × 224 FP32 reacting-flow grid. No image upscaling, frame interpolation, synthetic flame texture, or sharpened footage. The video shows one physical 1/120-second step per frame at 24 fps playback.</p>
<video controls playsinline preload="metadata" poster="preview.jpg"><source src="{html.escape(data['video_file'])}" type="video/mp4"></video>
<p><a href="{html.escape(data['video_file'])}">Open the original 2160 × 3840 MP4</a> · <a href="V7_native_pixel_crop.png">Inspect a 1:1 pixel crop</a></p>
<h2>Independent large stills</h2><div class="grid">{still_cards}</div>
<footer><p><a href="capture.json">Capture configuration and timings</a> · <a href="validation.json">Media verification</a> · <a href="initialization.json">Starting-state provenance</a></p>
<p class="note">Software OpenGL execution, not a hardware-GPU performance demonstration. Approximate constant-density gas combustion and one-way char particles; no experimental physical calibration or EmberGen comparison. Fine-grid evolution begins from an explicitly transferred earlier numerical state, not an old video.</p></footer></main></html>'''
    (a.capture/'index.html').write_text(gallery)
    tests=valid['numerical_runtime_checks']
    release=f'''# CYBR FIRE V7 — native high-resolution capture\n\nThe completed clip contains {data['frames']} natively rendered 2160 × 3840 frames, played at 24 fps. The fluid grid is 224 × 392 × 224 ({data['simulated_cells']:,} cells), at {data['cell_spacing_m']*1000:.6f} mm cell spacing. Two independent 3240 × 5760 stills use two camera samples per pixel.\n\nThis is **5× slow motion**, covering sampled physical times {data['physical_sample_time_s'][0]:.8f}–{data['physical_sample_time_s'][1]:.8f} s. It is not a real-time benchmark or a longer interval padded with interpolated frames.\n\nThe original {tests} numerical/runtime checks and {valid['passed']} media/release checks passed. Extracted-source checks are reported separately in the external packaging validation; they are not assumed merely because the ZIP can be opened.\n\nThe principal changes are authoritative FP32 image fields beyond the previous per-buffer size ceiling, lifetime-based scratch reuse, bounded-memory diagnostics/checkpoints, exact global-camera band rendering, and stable particle-event ordering. The 19.67-million-cell capture uses a 120 Hz clock and up to 16 local characteristic subsegments.\n\nThe capture is a new computation, not an image upscale. The earlier numerical checkpoint is conservatively transferred, reprojected, and evolved on the new grid. This is not a grid-convergence study or a matched camera/trajectory comparison with the older video.\n\nMedian synchronized software-adapter costs were {data['simulation_median_ms']/1000:.3f} s for simulation advancement, {data['lighting_median_ms']/1000:.3f} s for lighting preparation, and {data['native_render_median_ms']/1000:.3f} s for the native primary/render-readback-tonemap pass per output frame. These are shared-environment capture timings, not hardware GPU throughput.\n\nThe reproducible project package includes the source, starting checkpoint, media and evidence. The source-only archive excludes large caches and media. The media archive excludes code/caches. Lossless frame masters and the final checkpoint were retained and validated in the working capture but are not duplicated in the smaller media archive.\n\nKnown limits: dense storage, constant-density reduced chemistry, bounded but nonconservative transport, approximate lighting, one-way particles, no physical calibration, no hardware-GPU benchmark, no superiority-to-EmberGen claim.\n'''
    accuracy=valid['accuracy_diagnostic']
    release += f"\n## Numerical accuracy indicator\n\nThe maximum sampled face-component Courant number was {accuracy['maximum_sampled_face_component_courant']:.6f}; the nominal local tracing budget is {accuracy['nominal_local_trace_budget']:.1f}. Budget exceedance flagged: **{accuracy['exceeds_nominal_budget']}**. This global face-speed indicator is not a direct trajectory-error measurement. A finite, bounded solution and a higher cell count do not establish temporal or spatial convergence.\n"
    (root/'RELEASE.md').write_text(release);(a.capture/'RELEASE.md').write_text(release)
    (root/'evidence/capture-summary.json').write_text(json.dumps({k:v for k,v in data.items() if k!='measurements'},indent=2))
    shutil.copyfile(a.capture/'validation.json',root/'evidence/media-validation.json')
    shutil.copyfile(a.capture/'initialization.json',root/'evidence/initialization-provenance.json')
    files=[]
    for directory in ['cybrfire','shaders','tests','docs','examples']:
        files.extend(p for p in (root/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    files.extend(root/p for p in ['README.md','RELEASE.md','requirements.txt','requirements-tested.txt'])
    files.extend(root/'tools'/p for p in ['initialize_v7.py','replay_v7.py','validate_capture.py','package_release.py'])
    evidence_names=['device-limits.json','environment.json','tests.json','extended-tests.json','runtime-tests.json','v5-tests.json','v6-tests.json',
                    'particle-allocation-tests.json','native-field-tests.json','streaming-tests.json',
                    'legacy-regressions.log','legacy-regressions.exit','native-field-tests.log','native-field-tests.exit',
                    'streaming-tests.log','streaming-tests.exit','replay-v7.log','replay-v7.exit',
                    'warmup-19M.log','capture-summary.json','media-validation.json','media-validation.log','initialization-provenance.json']
    files.extend(root/'evidence'/p for p in evidence_names if (root/'evidence'/p).exists())
    entries=[(f,'CYBR_FIRE_V7/'+f.relative_to(root).as_posix()) for f in sorted(set(files))]
    # Preserve failures as explicitly classified development evidence, not passing release reports.
    for name in ['prepare.log','prepare.exit','particle-order-before-fix.json']:
        f=root/'evidence'/name
        if f.exists():entries.append((f,'CYBR_FIRE_V7/evidence/development/'+name))
    source=a.destination/'CYBR_FIRE_V7_source.zip'
    source_info=checked_archive(source,entries)
    print('Source archive created; checking the extracted copy.',flush=True)
    extraction=a.destination/'v7-extracted-verification'
    if extraction.exists():shutil.rmtree(extraction)
    extraction.mkdir()
    with zipfile.ZipFile(source) as z:z.extractall(extraction)
    working=extraction/'CYBR_FIRE_V7';executions=[]
    for name,command in [('inherited',[sys.executable,'-m','cybrfire','test']),
                         ('native',[sys.executable,'tests/test_native_fields.py']),
                         ('streaming',[sys.executable,'tests/test_streaming.py'])]:
        log_path=root/'evidence'/('extracted-'+name+'.log')
        with log_path.open('wb') as log:
            result=subprocess.run(command,cwd=working,env=env,stdout=log,stderr=subprocess.STDOUT)
        executions.append({'name':name,'command':command,'exit_code':result.returncode,'log_sha256':digest(log_path)})
        if result.returncode:raise RuntimeError(f'Extracted source failed: {name}')
    extracted_count=0
    for name in valid['tests']:
        report=json.loads((working/'evidence'/(name+'.json')).read_text())
        if report['failed']:raise RuntimeError('Extracted test failures: '+name)
        extracted_count+=report['passed']
    if extracted_count!=tests:raise RuntimeError('Extracted source test-count mismatch')
    media_names=[data['video_file'],'V7_first_frame_2160x3840.png',*[s['file'] for s in data['stills']],
                 'V7_native_pixel_crop.png','preview.jpg','index.html','RELEASE.md','capture.json','validation.json',
                 'derived-media.json','initialization.json','scene.json','ffmpeg.log']
    media_entries=[(a.capture/name,'CYBR_FIRE_V7_media/'+name) for name in media_names]
    gallery_info=checked_archive(a.destination/'CYBR_FIRE_V7_4K_media.zip',media_entries)
    project_entries=entries+[(a.checkpoint,'CYBR_FIRE_V7/cache/v7-capture-start.npz')]
    project_entries += [(file,'CYBR_FIRE_V7/media/'+file.name) for file,_ in media_entries]
    project_info=checked_archive(a.destination/'CYBR_FIRE_V7_reproducible_project.zip',project_entries)
    status={'release':'CYBR FIRE V7 / native 4K','status':'passed','verified_utc':datetime.now(timezone.utc).isoformat(),
            'core_sha256':data['core_sha256'],'capture_validation_sha256':digest(a.capture/'validation.json'),
            'source_tests_passed':tests,'extracted_source_tests_passed':extracted_count,'executed_from_extracted_archive':True,
            'extracted_executions':executions,'archives':[source_info,gallery_info,project_info],
            'project_start_checkpoint_included':True,'project_final_checkpoint_included':False,
            'lossless_frame_masters_in_media_archive':False,
            'qualification':'Numerical/runtime and delivered-file verification, not physical calibration, grid convergence, or a hardware benchmark.'}
    (a.capture/'packaging-validation.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status,indent=2),flush=True)


if __name__=='__main__':main()
