# CYBR FIRE V7 — native high-resolution capture

The completed clip contains 48 natively rendered 2160 × 3840 frames, played at 24 fps. The fluid grid is 224 × 392 × 224 (19,668,992 cells), at 8.571429 mm cell spacing. Two independent 3240 × 5760 stills use two camera samples per pixel.

This is **5× slow motion**, covering sampled physical times 4.65000000–5.04166667 s. It is not a real-time benchmark or a longer interval padded with interpolated frames.

The original 180 numerical/runtime checks and 196 media/release checks passed. Extracted-source checks are reported separately in the external packaging validation; they are not assumed merely because the ZIP can be opened.

The principal changes are authoritative FP32 image fields beyond the previous per-buffer size ceiling, lifetime-based scratch reuse, bounded-memory diagnostics/checkpoints, exact global-camera band rendering, and stable particle-event ordering. The 19.67-million-cell capture uses a 120 Hz clock and up to 16 local characteristic subsegments.

The capture is a new computation, not an image upscale. The earlier numerical checkpoint is conservatively transferred, reprojected, and evolved on the new grid. This is not a grid-convergence study or a matched camera/trajectory comparison with the older video.

Median synchronized software-adapter costs were 15.066 s for simulation advancement, 2.067 s for lighting preparation, and 27.324 s for the native primary/render-readback-tonemap pass per output frame. These are shared-environment capture timings, not hardware GPU throughput.

The reproducible project package includes the source, starting checkpoint, media and evidence. The source-only archive excludes large caches and media. The media archive excludes code/caches. Lossless frame masters and the final checkpoint were retained and validated in the working capture but are not duplicated in the smaller media archive.

Known limits: dense storage, constant-density reduced chemistry, bounded but nonconservative transport, approximate lighting, one-way particles, no physical calibration, no hardware-GPU benchmark, no superiority-to-EmberGen claim.

## Numerical accuracy indicator

The maximum sampled face-component Courant number was 38.454541; the nominal local tracing budget is 32.0. Budget exceedance flagged: **True**. This global face-speed indicator is not a direct trajectory-error measurement. A finite, bounded solution and a higher cell count do not establish temporal or spatial convergence.
