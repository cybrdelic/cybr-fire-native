# Ignis Fire Dynamics Lab — Restored Visuals

Open **Ignis.html** in a browser. The simulation, recordings, and comparison images are embedded in the file. To work with the modules, serve the included **source/** directory as a static site.

Under **Combustion → Model**, **Enhanced** runs gas transport, heat release, and thermal expansion with independently controlled sampling and lighting. Changing expansion restarts the scene. **Original** runs the first release’s solver and renderer. **Revised** includes a separate solid-fuel model, volume renderer, and thermal controls. Enhanced shows **Interrupted** and waits for Play, Step, or Replay after a running engine fails and restarts the case in the 2D fallback. Under **Rendering → Engine**, choose the WebGL volume, the 2D slice, or the Enhanced model’s optional CPU volume. The CPU volume supports orbit, zoom, and heat injection. Changing engines restarts the scene and preserves the model, camera, controls, and playback state. A browser without WebGL starts on the 2D slice. Switching from Enhanced CPU volume to Original or Revised selects the matching 2D solver.

## Controls

Drag to orbit in 3D. Scroll or pinch to zoom. Press B to toggle the heat brush, or hold Shift as you drag. Space toggles playback, period advances one step, and R restarts the scene. Open the performance display for frame timings and adaptive resolution. Choose **Measure 10 s** during playback to record the active scene's rendered-frame submission rate, 95th-percentile gap between submissions, and ratio of simulated time to wall time. The solver timing covers all solver updates submitted for a frame. Enhanced also reports dropped clock time and collects 95th-percentile samples for lighting, surface, volume, and resolve passes. GPU elapsed times require support for timer queries. The viewport camera button saves a PNG.

Select Wood crib, Pool fire, Jet flame, Crosswind, Fireball, Ground burst, Ember bed, or Pulsing vent. Fireball and Ground burst run once per scene reset. **Replay burst** restarts the event and resumes playback. Ember bed evolves continuously, and Pulsing vent cycles through burning and cooling. These four presets activate the Enhanced model across the WebGL, CPU volume, and 2D slice engines. The Revised WebGL Wood crib and Crosswind presets offer a **Wood temperature** view. Use the Revised model’s **Cold restart** and **Ignite base** controls to observe ignition from a cold fuel bed. Enhanced uses the same 1/60-second solver step for playback and manual stepping. A delayed frame can submit multiple equal steps. The scheduler caps work per frame and bounds pending time to 0.25 seconds. On a device that cannot keep up, the viewport shows **Behind** and the profiler reports how much clock time was dropped. A fixed sequence of inputs at the same simulation steps reproduces the trajectory on the same engine and quality setting. Changing GPU quality rebuilds the grid.

| GPU quality | Grid | Cells |
| --- | --- | ---: |
| Low | 32 × 48 × 32 | 49,152 |
| Medium | 48 × 72 × 48 | 165,888 |
| High | 64 × 96 × 64 | 393,216 |
| Ultra | 80 × 120 × 80 | 768,000 |

## Model

The 3D solver advects heat, soot, fuel, oxygen, and velocity through a finite grid, applies buoyancy and vorticity forces, and projects velocity against a pressure field. The burst presets briefly seed expanding shapes that advect through the reacting flow. Enhanced uses the v10 visual baseline, including procedural flame-sheet detail and soot-driven shading. The planar solver uses its own transport and shading on a 104 × 124 grid. The optional 3D CPU solver uses a separate reduced model. The status bar reports the active grid dimensions.

Compare shows independently evolved fire states at matching simulation time, quality, camera, and exposure. The 3D comparison uses captured WebGL frames. The planar comparison uses captured 2D frames. **Wood** plays a 3D recording of the chosen model. **Presets** plays a reel of the four new scenarios. The 3D Original–Enhanced comparison includes a side-by-side motion download.

The GPU volume, CPU volume, and 2D slice use different numerical models. The profiler describes the engine and quality setting you are using. Presets use normalized units for visual effects, and the light transport uses approximations.
